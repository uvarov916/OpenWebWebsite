<?php

class PeThemeViewLayoutModuleFormText extends PeThemeViewLayoutModuleText {

	public function group() {
		return "column";
	}
}

?>
