<?php

class PeThemeViewLayoutModuleFormContainer extends PeThemeViewLayoutModuleContainer {
	
	public function render() {
		$this->template();
	}
}

?>
