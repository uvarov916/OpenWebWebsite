<section class="share-block container">


	<div class="row">
		<div class="title col-sm-12">
			<h2><?php _e( 'Sharing makes you an awesome human being.' ,'Pixelentity Theme/Plugin'); ?></h2>
			<p><?php _e( 'Share this project if you like it!' ,'Pixelentity Theme/Plugin'); ?></p>
		</div>
	</div>


	<div class="row">
		<div class="col-sm-12">

			<ul class="addthis_toolbox addthis_default_style">
				<li><a class="addthis_button_facebook_like" fb:like:layout="button_count"></a></li>
				<li><a class="addthis_button_tweet"></a></li>
				<li><a class="addthis_button_pinterest_pinit" pi:pinit:layout="horizontal" pi:pinit:url="http://www.addthis.com/features/pinterest" pi:pinit:media="http://www.addthis.com/cms-content/images/features/pinterest-lg.png"></a>
				<li><a class="addthis_button_google_plusone" g:plusone:size="medium"></a>
				<li><a class="addthis_counter addthis_pill_style"></a>
			</ul>
			<script type="text/javascript">var addthis_config = {"data_track_addressbar":false};</script>
			<script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-52e6e19374a8b484"></script>

		</div>
	</div>
	
</section>