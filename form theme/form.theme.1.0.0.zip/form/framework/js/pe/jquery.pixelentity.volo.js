(function ($) {
	"use strict";
	/*jslint undef: false, browser: true, devel: false, eqeqeq: false, bitwise: false, white: false, plusplus: false, regexp: false, nomen: false */ 
	/*jshint undef: false, browser: true, devel: false, eqeqeq: false, bitwise: false, white: false, plusplus: false, regexp: false, nomen: false, validthis: true */
	/*global jQuery,setTimeout,setInterval,clearInterval,clearTimeout,WebKitCSSMatrix,pixelentity */
	
	$.pixelentity = $.pixelentity || {version: '1.0.0'};
	
	$.pixelentity.peVolo = {	
		conf: {
			api: false,
			count: 1,
			transition: 500
		} 
	};
	
	$.extend($.easing,{
		easeOutQuad: function (x, t, b, c, d) {
			return c*((t=t/d-1)*t*t + 1) + b;
		}
	});
	
	var ua = navigator.userAgent.toLowerCase();
	var iDev = ua.match(/(iphone|ipod|ipad)/) !== null;
	var android = !iDev && ua.match(/android ([^;]+)/);
	if (android) {
		android = android[1].split(/\./);
		android = parseFloat(android.shift() + "." + android.join(""));
	} else {
		android = false;
	}
	var mobile = (iDev || android || ua.match(/(android|blackberry|webOS|opera mobi)/) !== null);
	
	var style = document.createElement("div").style;
	var prefix,prefixes = ["O","ms","Webkit","Moz"];
	var test, loop;
	var transform = false, transitionDuration = false, use3d = false;
	
	for (var i=0; i<prefixes.length;i++) {
		test = prefixes[i]+"Transform";
		if (test in style) {
			transform = test;
			prefix = prefixes[i];
			continue;
		}
	}
	
	if (transform) {
		use3d = ('WebKitCSSMatrix' in window && 'm11' in new WebKitCSSMatrix());
		test = prefix+"Transition";
		transitionDuration = (test in style) ? test : false;
	}
	
	if (!transitionDuration) {
		loop = window.requestAnimationFrame || 
			window.webkitRequestAnimationFrame || 
			window.mozRequestAnimationFrame || 
			window.oRequestAnimationFrame || 
			window.msRequestAnimationFrame ||
			function (callback) {
				setTimeout(callback,25);
			};		
	}
	
	function PeVolo(target, conf) {
		var w;
		var slides = [];
		var max;
		var wrapper;
		var current = 0;
		var from = 0;
		var to = 0;
		var begin = 0;
		var scroller;
		var isScrolling = false;
		var touchX,touchY,touchAmountX,touchAmountY,touchScrollX;
		var currentPos = 0;
		var delay = 0;
		var pausedFrom = 0;
		var mouseOver = false;
		var timer;
		var minH = 1;
		var maxH = Number.MAX_VALUE;
		var rH = "auto";
		var inited = false;
		var showAtOnce = conf.count;
		var slideWidth;
		var ptarget;
		
		// init function
		function start() {
			inited = true;
			
			target.addClass("peVolo peNeedResize");
			
			if (mobile) {
				target.addClass("peVoloMobile");
			}
			
			if (target.find("> div.peWrap:eq(0)").length === 0) {
				// no wrapper, add one
				target.wrapInner('<div class="peWrap"></div>');
			}
			
			var tokens = (target.attr("data-height") || "").split(/,| /);
			
			if (tokens[0]) {
				minH = parseInt(tokens[0],10);
			}
			
			if (tokens[1]) {
				rH = $.inArray(tokens[1],["auto","container"]) >= 0 ? tokens[1] : parseFloat(tokens[1],10);
			} 
			
			if (tokens[2]) {
				maxH = parseInt(tokens[2],10);
			}
			
			if (rH === "container") {
				ptarget = target.closest(".pe-full-page");
				ptarget = ptarget.length > 0 ? ptarget : target.parent();
				target.height(ptarget.height());
			} else if (rH === 0) {
				if (minH > 1) {
					target.height(minH);
				}
			} else if (rH === "auto") {
				var firstImg = target.find("img").not(".peCaption img").eq(0);
				if (firstImg.length > 0) {
					var iw = firstImg[0].naturalWidth || firstImg.attr("width") || firstImg.width();
					var ih = firstImg[0].naturalHeight || firstImg.attr("height") || firstImg.height();					
					rH = (iw / ih)*showAtOnce;
				} else {
					rH = 0;
				}
			}
			
			slideWidth = target.attr("data-slidewidth");
			if (slideWidth) {
				conf.slideWidth = parseInt(slideWidth,10);
			}
			
			wrapper = target.find("> div:eq(0)");
			var allSlides = wrapper.find("> div").each(addSlide);
			scroller = wrapper[0].style;
			max = slides.length;
			resize();
			wrapper.css("visibility","visible");
			allSlides.css("visibility","visible").show();
			
			if (!target.hasClass("pe-no-resize") && target.closest(".pe-no-resize").length === 0) {
				$(window).bind("resize",windowHandler);
			}
			
			target.bind("resize",windowHandler);
			
			/*
			if (target.parent().hasClass("scalable")) {
				target.parent().bind("resize",windowHandler);
			}
			*/
			
			target.bind("touchstart touchmove touchend",touchHandler);
			if (target.attr("data-autopause") !== "disabled") {
				target.bind("mouseenter mouseleave",mouseHandler);
			}
			
			if (transitionDuration) {
				target.bind(prefix.toLowerCase()+"TransitionEnd transitionend",setTimer);
			}
			setTimer();
			setTimeout(fireReady,100);
			//target.trigger("resize.pixelentity");
			return true;

		}
		
		function fireReady() {
			target.trigger("ready.pixelentity",{"slides":slides.length,markup:slides});
			target.triggerHandler("change.pixelentity",{"slideIdx":1});
			$(window).trigger("pe-lazyloading-refresh");
		}

		
		function startTimer() {
			if (!inited || delay === 0) {
				return;
			}
			var pause = pausedFrom > 0 ? $.now() - pausedFrom : 0;
			pausedFrom = 0;
			pause = delay - pause;
			if (pause > 0) {
				stopTimer();
				timer = setTimeout(next,pause);				
			} else {
				next();
			}
		}
		
		function pauseTimer() {
			if (!inited) {
				return;
			}
			pausedFrom = $.now();
			stopTimer();
		}
		
		function stopTimer() {
			clearTimeout(timer);
		}
		
		function addSlide(idx,el) {
			slides.push($(el));
		}

		function resize(size) {
			if (!inited) {
				return;
			}
			size = typeof size === "undefined" ? target.width() : size;
			
			if (size === w && rH != "container") {
				return;
			}
			
			w = size;
			
			var slide,img,ratio;
			
			if (slideWidth > 0) {
				showAtOnce = Math.floor(w/slideWidth);
				showAtOnce = Math.max(1,showAtOnce);
			}
			
			if (showAtOnce > 1) {
				size = Math.floor(w/showAtOnce)*showAtOnce;
				target.css("margin-right",(w-size));
				w = size;
			}
			
			target.attr("data-show-navigation",showAtOnce < slides.length ? "yes" : "no");
			target.trigger("pe-carousel-navigation");
			
			var newH = false;
			
			if (rH > 0) {
				newH = (w/rH)/showAtOnce;
				newH = Math.max(minH,Math.min(maxH,newH));
			}
			
			if (rH === "container") {
				newH = ptarget.height();
				newH = Math.max(minH,Math.min(maxH,newH));
			}
			
			var scaler,iw,ih;
			
			for (var i = 0; i < max; i++) {
				slide = slides[i];
				slide.width(w/showAtOnce);
				if (newH) {
					// test this
					slide.height(newH);
				}
				if (slide.hasClass("scale")) {
					img = slide.find("img").not(".peCaption img").eq(0);
					if (img.length > 0) {
						img.css("max-width","none");
						if (true) {
							iw = img[0].naturalWidth || img.attr("width");
							ih = img[0].naturalHeight || img.attr("height");
							scaler = $.pixelentity.Geom.getScaler("fillmax","center","top",w,newH,iw,ih);
							img.transform(scaler.ratio,scaler.offset.w,scaler.offset.h,iw,ih,true);
							//ratio = (w/img[0].naturalWidth)/showAtOnce;
							//console.log(scaler);
							//img[0].style[transform] = "scale("+ratio+","+ratio+")";
							//img.transform(0.5,0,0,w,h)
						} else {
							img.width(w/showAtOnce);
						}
					}
				}
			}
			wrapper.width(w*max/showAtOnce);
			
			if (newH) {
				target.height(newH);
				// test this
				wrapper.height(newH);
			}
			
			if (!isScrolling) {
				scroll(currentPos,0);
			}
			
			target.trigger("resize.pixelentity");
		}
		
		function next() {
			if (!inited || max <= showAtOnce) {
				return;
			}
			current = (current + 1) % (max-showAtOnce+1);

			jumpTo(current);
		}
		
		function prev() {
			if (!inited || max <= showAtOnce) {
				return;
			}
			current--;
			if (current < 0) {
				current += (max-showAtOnce+1);
			}
			jumpTo(current);
		}

		
		function jumpTo(idx) {
			if (!inited) {
				return;
			}
			
			target.find(".peActiveWidget").trigger("disable.pixelentity");
			
			current = idx;
			from = to;
			to = 100*(idx/max);
			begin = $.now();
			touchAmountX = 0;
			isScrolling = true;
			target.triggerHandler("change.pixelentity",{"slideIdx":idx+1});
			if (transitionDuration) {
				currentPos = to;
				scroll(to,conf.transition);
			} else {
				tick();				
			}
		}
		
		function scroll(pos,duration) {
			pos =-pos;
			if (transform) {
				if (transitionDuration && typeof duration !== "undefined") {
					scroller[transitionDuration] = duration+"ms";
				}
				scroller[transform] = use3d ? "translate3d("+pos+"%,0,0)" : "translate("+pos+"%,0)";
			} else {
				wrapper.css("margin-left",parseInt(pos*(w*max/showAtOnce)/100,10));
			}
		}
		
		function tick() {
			if (touchAmountX !== 0) {
				return;
			}
			var elapsed = Math.min(conf.transition,$.now()-begin);
			var pos = $.easing.easeOutQuad(0,elapsed,from,to-from,conf.transition);
			currentPos = pos;
			scroll(pos,0);
			setTimer();
			if (elapsed < conf.transition) {
				loop(tick);
			} else {
				setTimer();
			}
		}
		
		function setTimer() {
			isScrolling = false;
			var sdelay = parseInt(slides[current].attr("data-delay"),10)*1000;
			if (sdelay > 0) {
				delay  = sdelay;
				if (mouseOver) {
					pauseTimer();
				} else {
					startTimer();					
				}
				
			}
		}

		
		function touchHandler(e) {
			var type = e.type;
			var te = e.originalEvent;
			
			
			switch (type) {
			case "touchstart":
				if(te.touches.length > 1 || te.scale && te.scale !== 1) {
					return;
				}
				touchX = te.touches[0].pageX;
				touchY = te.touches[0].pageY;
				touchAmountX = 0;
				break;
			case "touchmove":
				if(te.touches.length > 1 || te.scale && te.scale !== 1) {
					return;
				}
				stopTimer();
				touchAmountX = (te.touches[0].pageX - touchX);
				touchAmountY = Math.abs(te.touches[0].pageY - touchY);
				touchScrollX = currentPos-100*touchAmountX/(w*max);
				if (Math.abs(touchAmountX) > 2 /*|| Math.abs(touchAmountY) < 2*/) {
					e.preventDefault();
					e.stopPropagation();
				}
				scroll(touchScrollX,0);
				break;
			case "touchend":
				
				if (touchAmountX === 0) {
					return;
				}
				
				to = touchScrollX;
				
				var jumped = false;
				
				if (touchAmountX > 10 && current > 0) {
					jumped = true;
					prev();
				}
				
				if (touchAmountX < -10 && current < (max-showAtOnce)) {
					jumped = true;
					next();
				} 
				
				if (!jumped) {
					jumpTo(current);
				}
				
				touchAmountX = 0;
				
				break;
			}
		}

		function mouseHandler(e) {
			if (e.type === "mouseenter") {
				mouseOver = true;
				pauseTimer();
			} else {
				mouseOver = false;
				startTimer();
			}
		}
		
		function windowHandler(e) {
			resize();
		}

		
		function bind() {
			return target.bind.apply(target,arguments);
		}
		
		function getSlide(idx) {
			return slides[idx];
		}
		
		$.extend(this, {
			// plublic API
			bind: bind,
			show: function (idx) {
				jumpTo(idx-1);
			},
			next: next,
			prev: prev,
			pause: pauseTimer,
			resume: startTimer,
			resize: resize,
			getSlide: getSlide,
			current: function () {
				return current;
			},
			currentPos: function () {
				return currentPos;
			},
			destroy: function() {
				$(window).unbind("resize",windowHandler);
				
				target
					.unbind("touchstart touchmove touchend",touchHandler)
					.unbind("mouseenter mouseleave",mouseHandler)
					.unbind(prefix.toLowerCase()+"TransitionEnd transitionend",setTimer)
					.data("peVolo", null);
				
				target = undefined;
			}
		});
		
		// initialize
		$.pixelentity.preloader.load(target,start);
	}
	
	// jQuery plugin implementation
	$.fn.peVolo = function(conf) {
		
		// return existing instance	
		var api = this.data("peVolo");
		
		if (api) { 
			return api; 
		}
		
		conf = $.extend(true, {}, $.pixelentity.peVolo.conf, conf);
		
		// install the plugin for each entry in jQuery object
		this.each(function() {
			var el = $(this);
			api = new PeVolo(el, conf);
			el.data("peVolo", api); 
		});
		
		return conf.api ? api: this;		 
	};
	
}(jQuery));