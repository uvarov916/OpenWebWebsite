<?php

class PeThemeConstant_peVolo {
	public $options;

	public function __construct() {
		$this->options = array();
	}
	
}

?>
