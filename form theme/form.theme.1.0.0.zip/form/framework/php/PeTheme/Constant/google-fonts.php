<?php $fonts = array (
  'google' => 
  array (
    'ABeeZee' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => 'italic',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Abel' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Abril Fatface' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Aclonica' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Acme' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Actor' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Adamina' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Advent Pro' => 
    array (
      0 => 
      array (
        0 => '100',
        1 => '200',
        2 => '300',
        3 => 'regular',
        4 => '500',
        5 => '600',
        6 => '700',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'greek',
        2 => 'latin-ext',
      ),
    ),
    'Aguafina Script' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Akronim' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Aladin' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Aldrich' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Alef' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => '700',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Alegreya' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => 'italic',
        2 => '700',
        3 => '700italic',
        4 => '900',
        5 => '900italic',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Alegreya SC' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => 'italic',
        2 => '700',
        3 => '700italic',
        4 => '900',
        5 => '900italic',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Alex Brush' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Alfa Slab One' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Alice' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Alike' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Alike Angular' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Allan' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => '700',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Allerta' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Allerta Stencil' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Allura' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Almendra' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => 'italic',
        2 => '700',
        3 => '700italic',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Almendra Display' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Almendra SC' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Amarante' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Amaranth' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => 'italic',
        2 => '700',
        3 => '700italic',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Amatic SC' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => '700',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Amethysta' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Anaheim' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Andada' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Andika' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'cyrillic-ext',
        2 => 'latin-ext',
        3 => 'cyrillic',
      ),
    ),
    'Angkor' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'khmer',
      ),
    ),
    'Annie Use Your Telescope' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Anonymous Pro' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => 'italic',
        2 => '700',
        3 => '700italic',
      ),
      1 => 
      array (
        0 => 'greek-ext',
        1 => 'latin',
        2 => 'cyrillic-ext',
        3 => 'greek',
        4 => 'latin-ext',
        5 => 'cyrillic',
      ),
    ),
    'Antic' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Antic Didone' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Antic Slab' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Anton' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Arapey' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => 'italic',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Arbutus' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Arbutus Slab' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Architects Daughter' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Archivo Black' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Archivo Narrow' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => 'italic',
        2 => '700',
        3 => '700italic',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Arimo' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => 'italic',
        2 => '700',
        3 => '700italic',
      ),
      1 => 
      array (
        0 => 'greek-ext',
        1 => 'latin',
        2 => 'cyrillic-ext',
        3 => 'vietnamese',
        4 => 'greek',
        5 => 'latin-ext',
        6 => 'cyrillic',
      ),
    ),
    'Arizonia' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Armata' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Artifika' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Arvo' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => 'italic',
        2 => '700',
        3 => '700italic',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Asap' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => 'italic',
        2 => '700',
        3 => '700italic',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Asset' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Astloch' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => '700',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Asul' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => '700',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Atomic Age' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Aubrey' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Audiowide' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Autour One' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Average' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Average Sans' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Averia Gruesa Libre' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Averia Libre' => 
    array (
      0 => 
      array (
        0 => '300',
        1 => '300italic',
        2 => 'regular',
        3 => 'italic',
        4 => '700',
        5 => '700italic',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Averia Sans Libre' => 
    array (
      0 => 
      array (
        0 => '300',
        1 => '300italic',
        2 => 'regular',
        3 => 'italic',
        4 => '700',
        5 => '700italic',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Averia Serif Libre' => 
    array (
      0 => 
      array (
        0 => '300',
        1 => '300italic',
        2 => 'regular',
        3 => 'italic',
        4 => '700',
        5 => '700italic',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Bad Script' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'cyrillic',
      ),
    ),
    'Balthazar' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Bangers' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Basic' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Battambang' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => '700',
      ),
      1 => 
      array (
        0 => 'khmer',
      ),
    ),
    'Baumans' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Bayon' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'khmer',
      ),
    ),
    'Belgrano' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Belleza' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'BenchNine' => 
    array (
      0 => 
      array (
        0 => '300',
        1 => 'regular',
        2 => '700',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Bentham' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Berkshire Swash' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Bevan' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Bigelow Rules' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Bigshot One' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Bilbo' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Bilbo Swash Caps' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Bitter' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => 'italic',
        2 => '700',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Black Ops One' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Bokor' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'khmer',
      ),
    ),
    'Bonbon' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Boogaloo' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Bowlby One' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Bowlby One SC' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Brawler' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Bree Serif' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Bubblegum Sans' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Bubbler One' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Buda' => 
    array (
      0 => 
      array (
        0 => '300',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Buenard' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => '700',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Butcherman' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Butterfly Kids' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Cabin' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => 'italic',
        2 => '500',
        3 => '500italic',
        4 => '600',
        5 => '600italic',
        6 => '700',
        7 => '700italic',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Cabin Condensed' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => '500',
        2 => '600',
        3 => '700',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Cabin Sketch' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => '700',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Caesar Dressing' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Cagliostro' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Calligraffitti' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Cambo' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Candal' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Cantarell' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => 'italic',
        2 => '700',
        3 => '700italic',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Cantata One' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Cantora One' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Capriola' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Cardo' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => 'italic',
        2 => '700',
      ),
      1 => 
      array (
        0 => 'greek-ext',
        1 => 'latin',
        2 => 'greek',
        3 => 'latin-ext',
      ),
    ),
    'Carme' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Carrois Gothic' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Carrois Gothic SC' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Carter One' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Caudex' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => 'italic',
        2 => '700',
        3 => '700italic',
      ),
      1 => 
      array (
        0 => 'greek-ext',
        1 => 'latin',
        2 => 'greek',
        3 => 'latin-ext',
      ),
    ),
    'Cedarville Cursive' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Ceviche One' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Changa One' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => 'italic',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Chango' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Chau Philomene One' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => 'italic',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Chela One' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Chelsea Market' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Chenla' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'khmer',
      ),
    ),
    'Cherry Cream Soda' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Cherry Swash' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => '700',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Chewy' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Chicle' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Chivo' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => 'italic',
        2 => '900',
        3 => '900italic',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Cinzel' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => '700',
        2 => '900',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Cinzel Decorative' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => '700',
        2 => '900',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Clicker Script' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Coda' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => '800',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Coda Caption' => 
    array (
      0 => 
      array (
        0 => '800',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Codystar' => 
    array (
      0 => 
      array (
        0 => '300',
        1 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Combo' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Comfortaa' => 
    array (
      0 => 
      array (
        0 => '300',
        1 => 'regular',
        2 => '700',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'cyrillic-ext',
        2 => 'greek',
        3 => 'latin-ext',
        4 => 'cyrillic',
      ),
    ),
    'Coming Soon' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Concert One' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Condiment' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Content' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => '700',
      ),
      1 => 
      array (
        0 => 'khmer',
      ),
    ),
    'Contrail One' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Convergence' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Cookie' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Copse' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Corben' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => '700',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Courgette' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Cousine' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => 'italic',
        2 => '700',
        3 => '700italic',
      ),
      1 => 
      array (
        0 => 'greek-ext',
        1 => 'latin',
        2 => 'cyrillic-ext',
        3 => 'vietnamese',
        4 => 'greek',
        5 => 'latin-ext',
        6 => 'cyrillic',
      ),
    ),
    'Coustard' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => '900',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Covered By Your Grace' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Crafty Girls' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Creepster' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Crete Round' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => 'italic',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Crimson Text' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => 'italic',
        2 => '600',
        3 => '600italic',
        4 => '700',
        5 => '700italic',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Croissant One' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Crushed' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Cuprum' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => 'italic',
        2 => '700',
        3 => '700italic',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
        2 => 'cyrillic',
      ),
    ),
    'Cutive' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Cutive Mono' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Damion' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Dancing Script' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => '700',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Dangrek' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'khmer',
      ),
    ),
    'Dawning of a New Day' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Days One' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Delius' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Delius Swash Caps' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Delius Unicase' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => '700',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Della Respira' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Denk One' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Devonshire' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Didact Gothic' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'greek-ext',
        1 => 'latin',
        2 => 'cyrillic-ext',
        3 => 'greek',
        4 => 'latin-ext',
        5 => 'cyrillic',
      ),
    ),
    'Diplomata' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Diplomata SC' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Domine' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => '700',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Donegal One' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Doppio One' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Dorsa' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Dosis' => 
    array (
      0 => 
      array (
        0 => '200',
        1 => '300',
        2 => 'regular',
        3 => '500',
        4 => '600',
        5 => '700',
        6 => '800',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Dr Sugiyama' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Droid Sans' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => '700',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Droid Sans Mono' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Droid Serif' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => 'italic',
        2 => '700',
        3 => '700italic',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Duru Sans' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Dynalight' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'EB Garamond' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'cyrillic-ext',
        2 => 'vietnamese',
        3 => 'latin-ext',
        4 => 'cyrillic',
      ),
    ),
    'Eagle Lake' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Eater' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Economica' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => 'italic',
        2 => '700',
        3 => '700italic',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Electrolize' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Elsie' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => '900',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Elsie Swash Caps' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => '900',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Emblema One' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Emilys Candy' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Engagement' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Englebert' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Enriqueta' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => '700',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Erica One' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Esteban' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Euphoria Script' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Ewert' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Exo' => 
    array (
      0 => 
      array (
        0 => '100',
        1 => '100italic',
        2 => '200',
        3 => '200italic',
        4 => '300',
        5 => '300italic',
        6 => 'regular',
        7 => 'italic',
        8 => '500',
        9 => '500italic',
        10 => '600',
        11 => '600italic',
        12 => '700',
        13 => '700italic',
        14 => '800',
        15 => '800italic',
        16 => '900',
        17 => '900italic',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Expletus Sans' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => 'italic',
        2 => '500',
        3 => '500italic',
        4 => '600',
        5 => '600italic',
        6 => '700',
        7 => '700italic',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Fanwood Text' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => 'italic',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Fascinate' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Fascinate Inline' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Faster One' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Fasthand' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'khmer',
      ),
    ),
    'Fauna One' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Federant' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Federo' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Felipa' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Fenix' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Finger Paint' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Fjalla One' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Fjord One' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Flamenco' => 
    array (
      0 => 
      array (
        0 => '300',
        1 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Flavors' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Fondamento' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => 'italic',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Fontdiner Swanky' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Forum' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'cyrillic-ext',
        2 => 'latin-ext',
        3 => 'cyrillic',
      ),
    ),
    'Francois One' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Freckle Face' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Fredericka the Great' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Fredoka One' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Freehand' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'khmer',
      ),
    ),
    'Fresca' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Frijole' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Fruktur' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Fugaz One' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'GFS Didot' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'greek',
      ),
    ),
    'GFS Neohellenic' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => 'italic',
        2 => '700',
        3 => '700italic',
      ),
      1 => 
      array (
        0 => 'greek',
      ),
    ),
    'Gabriela' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Gafata' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Galdeano' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Galindo' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Gentium Basic' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => 'italic',
        2 => '700',
        3 => '700italic',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Gentium Book Basic' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => 'italic',
        2 => '700',
        3 => '700italic',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Geo' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => 'italic',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Geostar' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Geostar Fill' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Germania One' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Gilda Display' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Give You Glory' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Glass Antiqua' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Glegoo' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Gloria Hallelujah' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Goblin One' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Gochi Hand' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Gorditas' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => '700',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Goudy Bookletter 1911' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Graduate' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Grand Hotel' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Gravitas One' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Great Vibes' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Griffy' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Gruppo' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Gudea' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => 'italic',
        2 => '700',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Habibi' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Hammersmith One' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Hanalei' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Hanalei Fill' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Handlee' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Hanuman' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => '700',
      ),
      1 => 
      array (
        0 => 'khmer',
      ),
    ),
    'Happy Monkey' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Headland One' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Henny Penny' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Herr Von Muellerhoff' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Holtwood One SC' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Homemade Apple' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Homenaje' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'IM Fell DW Pica' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => 'italic',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'IM Fell DW Pica SC' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'IM Fell Double Pica' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => 'italic',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'IM Fell Double Pica SC' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'IM Fell English' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => 'italic',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'IM Fell English SC' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'IM Fell French Canon' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => 'italic',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'IM Fell French Canon SC' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'IM Fell Great Primer' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => 'italic',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'IM Fell Great Primer SC' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Iceberg' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Iceland' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Imprima' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Inconsolata' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => '700',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Inder' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Indie Flower' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Inika' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => '700',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Irish Grover' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Istok Web' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => 'italic',
        2 => '700',
        3 => '700italic',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'cyrillic-ext',
        2 => 'latin-ext',
        3 => 'cyrillic',
      ),
    ),
    'Italiana' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Italianno' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Jacques Francois' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Jacques Francois Shadow' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Jim Nightshade' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Jockey One' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Jolly Lodger' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Josefin Sans' => 
    array (
      0 => 
      array (
        0 => '100',
        1 => '100italic',
        2 => '300',
        3 => '300italic',
        4 => 'regular',
        5 => 'italic',
        6 => '600',
        7 => '600italic',
        8 => '700',
        9 => '700italic',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Josefin Slab' => 
    array (
      0 => 
      array (
        0 => '100',
        1 => '100italic',
        2 => '300',
        3 => '300italic',
        4 => 'regular',
        5 => 'italic',
        6 => '600',
        7 => '600italic',
        8 => '700',
        9 => '700italic',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Joti One' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Judson' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => 'italic',
        2 => '700',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Julee' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Julius Sans One' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Junge' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Jura' => 
    array (
      0 => 
      array (
        0 => '300',
        1 => 'regular',
        2 => '500',
        3 => '600',
      ),
      1 => 
      array (
        0 => 'greek-ext',
        1 => 'latin',
        2 => 'cyrillic-ext',
        3 => 'greek',
        4 => 'latin-ext',
        5 => 'cyrillic',
      ),
    ),
    'Just Another Hand' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Just Me Again Down Here' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Kameron' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => '700',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Karla' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => 'italic',
        2 => '700',
        3 => '700italic',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Kaushan Script' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Kavoon' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Keania One' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Kelly Slab' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
        2 => 'cyrillic',
      ),
    ),
    'Kenia' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Khmer' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'khmer',
      ),
    ),
    'Kite One' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Knewave' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Kotta One' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Koulen' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'khmer',
      ),
    ),
    'Kranky' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Kreon' => 
    array (
      0 => 
      array (
        0 => '300',
        1 => 'regular',
        2 => '700',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Kristi' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Krona One' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'La Belle Aurore' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Lancelot' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Lato' => 
    array (
      0 => 
      array (
        0 => '100',
        1 => '100italic',
        2 => '300',
        3 => '300italic',
        4 => 'regular',
        5 => 'italic',
        6 => '700',
        7 => '700italic',
        8 => '900',
        9 => '900italic',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'League Script' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Leckerli One' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Ledger' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
        2 => 'cyrillic',
      ),
    ),
    'Lekton' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => 'italic',
        2 => '700',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Lemon' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Libre Baskerville' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => 'italic',
        2 => '700',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Life Savers' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => '700',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Lilita One' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Lily Script One' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Limelight' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Linden Hill' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => 'italic',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Lobster' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'cyrillic-ext',
        2 => 'latin-ext',
        3 => 'cyrillic',
      ),
    ),
    'Lobster Two' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => 'italic',
        2 => '700',
        3 => '700italic',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Londrina Outline' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Londrina Shadow' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Londrina Sketch' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Londrina Solid' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Lora' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => 'italic',
        2 => '700',
        3 => '700italic',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Love Ya Like A Sister' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Loved by the King' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Lovers Quarrel' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Luckiest Guy' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Lusitana' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => '700',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Lustria' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Macondo' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Macondo Swash Caps' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Magra' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => '700',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Maiden Orange' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Mako' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Marcellus' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Marcellus SC' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Marck Script' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
        2 => 'cyrillic',
      ),
    ),
    'Margarine' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Marko One' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Marmelad' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
        2 => 'cyrillic',
      ),
    ),
    'Marvel' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => 'italic',
        2 => '700',
        3 => '700italic',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Mate' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => 'italic',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Mate SC' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Maven Pro' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => '500',
        2 => '700',
        3 => '900',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'McLaren' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Meddon' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'MedievalSharp' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Medula One' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Megrim' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Meie Script' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Merienda' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => '700',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Merienda One' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Merriweather' => 
    array (
      0 => 
      array (
        0 => '300',
        1 => '300italic',
        2 => 'regular',
        3 => 'italic',
        4 => '700',
        5 => '700italic',
        6 => '900',
        7 => '900italic',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Merriweather Sans' => 
    array (
      0 => 
      array (
        0 => '300',
        1 => '300italic',
        2 => 'regular',
        3 => 'italic',
        4 => '700',
        5 => '700italic',
        6 => '800',
        7 => '800italic',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Metal' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'khmer',
      ),
    ),
    'Metal Mania' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Metamorphous' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Metrophobic' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Michroma' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Milonga' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Miltonian' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Miltonian Tattoo' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Miniver' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Miss Fajardose' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Modern Antiqua' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Molengo' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Molle' => 
    array (
      0 => 
      array (
        0 => 'italic',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Monda' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => '700',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Monofett' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Monoton' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Monsieur La Doulaise' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Montaga' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Montez' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Montserrat' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => '700',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Montserrat Alternates' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => '700',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Montserrat Subrayada' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => '700',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Moul' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'khmer',
      ),
    ),
    'Moulpali' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'khmer',
      ),
    ),
    'Mountains of Christmas' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => '700',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Mouse Memoirs' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Mr Bedfort' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Mr Dafoe' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Mr De Haviland' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Mrs Saint Delafield' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Mrs Sheppards' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Muli' => 
    array (
      0 => 
      array (
        0 => '300',
        1 => '300italic',
        2 => 'regular',
        3 => 'italic',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Mystery Quest' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Neucha' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'cyrillic',
      ),
    ),
    'Neuton' => 
    array (
      0 => 
      array (
        0 => '200',
        1 => '300',
        2 => 'regular',
        3 => 'italic',
        4 => '700',
        5 => '800',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'New Rocker' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'News Cycle' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => '700',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Niconne' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Nixie One' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Nobile' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => 'italic',
        2 => '700',
        3 => '700italic',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Nokora' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => '700',
      ),
      1 => 
      array (
        0 => 'khmer',
      ),
    ),
    'Norican' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Nosifer' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Nothing You Could Do' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Noticia Text' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => 'italic',
        2 => '700',
        3 => '700italic',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'vietnamese',
        2 => 'latin-ext',
      ),
    ),
    'Noto Sans' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => 'italic',
        2 => '700',
        3 => '700italic',
      ),
      1 => 
      array (
        0 => 'greek-ext',
        1 => 'latin',
        2 => 'cyrillic-ext',
        3 => 'vietnamese',
        4 => 'greek',
        5 => 'latin-ext',
        6 => 'cyrillic',
      ),
    ),
    'Noto Serif' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => 'italic',
        2 => '700',
        3 => '700italic',
      ),
      1 => 
      array (
        0 => 'greek-ext',
        1 => 'latin',
        2 => 'cyrillic-ext',
        3 => 'vietnamese',
        4 => 'greek',
        5 => 'latin-ext',
        6 => 'cyrillic',
      ),
    ),
    'Nova Cut' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Nova Flat' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Nova Mono' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'greek',
      ),
    ),
    'Nova Oval' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Nova Round' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Nova Script' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Nova Slim' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Nova Square' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Numans' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Nunito' => 
    array (
      0 => 
      array (
        0 => '300',
        1 => 'regular',
        2 => '700',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Odor Mean Chey' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'khmer',
      ),
    ),
    'Offside' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Old Standard TT' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => 'italic',
        2 => '700',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Oldenburg' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Oleo Script' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => '700',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Oleo Script Swash Caps' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => '700',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Open Sans' => 
    array (
      0 => 
      array (
        0 => '300',
        1 => '300italic',
        2 => 'regular',
        3 => 'italic',
        4 => '600',
        5 => '600italic',
        6 => '700',
        7 => '700italic',
        8 => '800',
        9 => '800italic',
      ),
      1 => 
      array (
        0 => 'greek-ext',
        1 => 'latin',
        2 => 'cyrillic-ext',
        3 => 'vietnamese',
        4 => 'greek',
        5 => 'latin-ext',
        6 => 'cyrillic',
      ),
    ),
    'Open Sans Condensed' => 
    array (
      0 => 
      array (
        0 => '300',
        1 => '300italic',
        2 => '700',
      ),
      1 => 
      array (
        0 => 'greek-ext',
        1 => 'latin',
        2 => 'cyrillic-ext',
        3 => 'vietnamese',
        4 => 'greek',
        5 => 'latin-ext',
        6 => 'cyrillic',
      ),
    ),
    'Oranienbaum' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'cyrillic-ext',
        2 => 'latin-ext',
        3 => 'cyrillic',
      ),
    ),
    'Orbitron' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => '500',
        2 => '700',
        3 => '900',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Oregano' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => 'italic',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Orienta' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Original Surfer' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Oswald' => 
    array (
      0 => 
      array (
        0 => '300',
        1 => 'regular',
        2 => '700',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Over the Rainbow' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Overlock' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => 'italic',
        2 => '700',
        3 => '700italic',
        4 => '900',
        5 => '900italic',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Overlock SC' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Ovo' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Oxygen' => 
    array (
      0 => 
      array (
        0 => '300',
        1 => 'regular',
        2 => '700',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Oxygen Mono' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'PT Mono' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'cyrillic-ext',
        2 => 'latin-ext',
        3 => 'cyrillic',
      ),
    ),
    'PT Sans' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => 'italic',
        2 => '700',
        3 => '700italic',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'cyrillic-ext',
        2 => 'latin-ext',
        3 => 'cyrillic',
      ),
    ),
    'PT Sans Caption' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => '700',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'cyrillic-ext',
        2 => 'latin-ext',
        3 => 'cyrillic',
      ),
    ),
    'PT Sans Narrow' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => '700',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'cyrillic-ext',
        2 => 'latin-ext',
        3 => 'cyrillic',
      ),
    ),
    'PT Serif' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => 'italic',
        2 => '700',
        3 => '700italic',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'cyrillic-ext',
        2 => 'latin-ext',
        3 => 'cyrillic',
      ),
    ),
    'PT Serif Caption' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => 'italic',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'cyrillic-ext',
        2 => 'latin-ext',
        3 => 'cyrillic',
      ),
    ),
    'Pacifico' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Paprika' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Parisienne' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Passero One' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Passion One' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => '700',
        2 => '900',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Pathway Gothic One' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Patrick Hand' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'vietnamese',
        2 => 'latin-ext',
      ),
    ),
    'Patrick Hand SC' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'vietnamese',
        2 => 'latin-ext',
      ),
    ),
    'Patua One' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Paytone One' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Peralta' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Permanent Marker' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Petit Formal Script' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Petrona' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Philosopher' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => 'italic',
        2 => '700',
        3 => '700italic',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'cyrillic',
      ),
    ),
    'Piedra' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Pinyon Script' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Pirata One' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Plaster' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Play' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => '700',
      ),
      1 => 
      array (
        0 => 'greek-ext',
        1 => 'latin',
        2 => 'cyrillic-ext',
        3 => 'greek',
        4 => 'latin-ext',
        5 => 'cyrillic',
      ),
    ),
    'Playball' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Playfair Display' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => 'italic',
        2 => '700',
        3 => '700italic',
        4 => '900',
        5 => '900italic',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
        2 => 'cyrillic',
      ),
    ),
    'Playfair Display SC' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => 'italic',
        2 => '700',
        3 => '700italic',
        4 => '900',
        5 => '900italic',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
        2 => 'cyrillic',
      ),
    ),
    'Podkova' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => '700',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Poiret One' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
        2 => 'cyrillic',
      ),
    ),
    'Poller One' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Poly' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => 'italic',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Pompiere' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Pontano Sans' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Port Lligat Sans' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Port Lligat Slab' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Prata' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Preahvihear' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'khmer',
      ),
    ),
    'Press Start 2P' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'greek',
        2 => 'latin-ext',
        3 => 'cyrillic',
      ),
    ),
    'Princess Sofia' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Prociono' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Prosto One' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
        2 => 'cyrillic',
      ),
    ),
    'Puritan' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => 'italic',
        2 => '700',
        3 => '700italic',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Purple Purse' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Quando' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Quantico' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => 'italic',
        2 => '700',
        3 => '700italic',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Quattrocento' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => '700',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Quattrocento Sans' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => 'italic',
        2 => '700',
        3 => '700italic',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Questrial' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Quicksand' => 
    array (
      0 => 
      array (
        0 => '300',
        1 => 'regular',
        2 => '700',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Quintessential' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Qwigley' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Racing Sans One' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Radley' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => 'italic',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Raleway' => 
    array (
      0 => 
      array (
        0 => '100',
        1 => '200',
        2 => '300',
        3 => 'regular',
        4 => '500',
        5 => '600',
        6 => '700',
        7 => '800',
        8 => '900',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Raleway Dots' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Rambla' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => 'italic',
        2 => '700',
        3 => '700italic',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Rammetto One' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Ranchers' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Rancho' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Rationale' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Redressed' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Reenie Beanie' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Revalia' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Ribeye' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Ribeye Marrow' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Righteous' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Risque' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Roboto' => 
    array (
      0 => 
      array (
        0 => '100',
        1 => '100italic',
        2 => '300',
        3 => '300italic',
        4 => 'regular',
        5 => 'italic',
        6 => '500',
        7 => '500italic',
        8 => '700',
        9 => '700italic',
        10 => '900',
        11 => '900italic',
      ),
      1 => 
      array (
        0 => 'greek-ext',
        1 => 'latin',
        2 => 'cyrillic-ext',
        3 => 'vietnamese',
        4 => 'greek',
        5 => 'latin-ext',
        6 => 'cyrillic',
      ),
    ),
    'Roboto Condensed' => 
    array (
      0 => 
      array (
        0 => '300',
        1 => '300italic',
        2 => 'regular',
        3 => 'italic',
        4 => '700',
        5 => '700italic',
      ),
      1 => 
      array (
        0 => 'greek-ext',
        1 => 'latin',
        2 => 'cyrillic-ext',
        3 => 'vietnamese',
        4 => 'greek',
        5 => 'latin-ext',
        6 => 'cyrillic',
      ),
    ),
    'Roboto Slab' => 
    array (
      0 => 
      array (
        0 => '100',
        1 => '300',
        2 => 'regular',
        3 => '700',
      ),
      1 => 
      array (
        0 => 'greek-ext',
        1 => 'latin',
        2 => 'cyrillic-ext',
        3 => 'vietnamese',
        4 => 'greek',
        5 => 'latin-ext',
        6 => 'cyrillic',
      ),
    ),
    'Rochester' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Rock Salt' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Rokkitt' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => '700',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Romanesco' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Ropa Sans' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => 'italic',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Rosario' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => 'italic',
        2 => '700',
        3 => '700italic',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Rosarivo' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => 'italic',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Rouge Script' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Ruda' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => '700',
        2 => '900',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Rufina' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => '700',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Ruge Boogie' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Ruluko' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Rum Raisin' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Ruslan Display' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'cyrillic-ext',
        2 => 'latin-ext',
        3 => 'cyrillic',
      ),
    ),
    'Russo One' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
        2 => 'cyrillic',
      ),
    ),
    'Ruthie' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Rye' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Sacramento' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Sail' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Salsa' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Sanchez' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => 'italic',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Sancreek' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Sansita One' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Sarina' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Satisfy' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Scada' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => 'italic',
        2 => '700',
        3 => '700italic',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
        2 => 'cyrillic',
      ),
    ),
    'Schoolbell' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Seaweed Script' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Sevillana' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Seymour One' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
        2 => 'cyrillic',
      ),
    ),
    'Shadows Into Light' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Shadows Into Light Two' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Shanti' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Share' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => 'italic',
        2 => '700',
        3 => '700italic',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Share Tech' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Share Tech Mono' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Shojumaru' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Short Stack' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Siemreap' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'khmer',
      ),
    ),
    'Sigmar One' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Signika' => 
    array (
      0 => 
      array (
        0 => '300',
        1 => 'regular',
        2 => '600',
        3 => '700',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Signika Negative' => 
    array (
      0 => 
      array (
        0 => '300',
        1 => 'regular',
        2 => '600',
        3 => '700',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Simonetta' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => 'italic',
        2 => '900',
        3 => '900italic',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Sintony' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => '700',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Sirin Stencil' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Six Caps' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Skranji' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => '700',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Slackey' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Smokum' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Smythe' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Sniglet' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => '800',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Snippet' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Snowburst One' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Sofadi One' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Sofia' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Sonsie One' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Sorts Mill Goudy' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => 'italic',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Source Code Pro' => 
    array (
      0 => 
      array (
        0 => '200',
        1 => '300',
        2 => 'regular',
        3 => '500',
        4 => '600',
        5 => '700',
        6 => '900',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Source Sans Pro' => 
    array (
      0 => 
      array (
        0 => '200',
        1 => '200italic',
        2 => '300',
        3 => '300italic',
        4 => 'regular',
        5 => 'italic',
        6 => '600',
        7 => '600italic',
        8 => '700',
        9 => '700italic',
        10 => '900',
        11 => '900italic',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'vietnamese',
        2 => 'latin-ext',
      ),
    ),
    'Special Elite' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Spicy Rice' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Spinnaker' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Spirax' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Squada One' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Stalemate' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Stalinist One' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
        2 => 'cyrillic',
      ),
    ),
    'Stardos Stencil' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => '700',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Stint Ultra Condensed' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Stint Ultra Expanded' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Stoke' => 
    array (
      0 => 
      array (
        0 => '300',
        1 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Strait' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Sue Ellen Francisco' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Sunshiney' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Supermercado One' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Suwannaphum' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'khmer',
      ),
    ),
    'Swanky and Moo Moo' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Syncopate' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => '700',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Tangerine' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => '700',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Taprom' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'khmer',
      ),
    ),
    'Tauri' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Telex' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Tenor Sans' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'cyrillic-ext',
        2 => 'latin-ext',
        3 => 'cyrillic',
      ),
    ),
    'Text Me One' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'The Girl Next Door' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Tienne' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => '700',
        2 => '900',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Tinos' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => 'italic',
        2 => '700',
        3 => '700italic',
      ),
      1 => 
      array (
        0 => 'greek-ext',
        1 => 'latin',
        2 => 'cyrillic-ext',
        3 => 'vietnamese',
        4 => 'greek',
        5 => 'latin-ext',
        6 => 'cyrillic',
      ),
    ),
    'Titan One' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Titillium Web' => 
    array (
      0 => 
      array (
        0 => '200',
        1 => '200italic',
        2 => '300',
        3 => '300italic',
        4 => 'regular',
        5 => 'italic',
        6 => '600',
        7 => '600italic',
        8 => '700',
        9 => '700italic',
        10 => '900',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Trade Winds' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Trocchi' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Trochut' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => 'italic',
        2 => '700',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Trykker' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Tulpen One' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Ubuntu' => 
    array (
      0 => 
      array (
        0 => '300',
        1 => '300italic',
        2 => 'regular',
        3 => 'italic',
        4 => '500',
        5 => '500italic',
        6 => '700',
        7 => '700italic',
      ),
      1 => 
      array (
        0 => 'greek-ext',
        1 => 'latin',
        2 => 'cyrillic-ext',
        3 => 'greek',
        4 => 'latin-ext',
        5 => 'cyrillic',
      ),
    ),
    'Ubuntu Condensed' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'greek-ext',
        1 => 'latin',
        2 => 'cyrillic-ext',
        3 => 'greek',
        4 => 'latin-ext',
        5 => 'cyrillic',
      ),
    ),
    'Ubuntu Mono' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => 'italic',
        2 => '700',
        3 => '700italic',
      ),
      1 => 
      array (
        0 => 'greek-ext',
        1 => 'latin',
        2 => 'cyrillic-ext',
        3 => 'greek',
        4 => 'latin-ext',
        5 => 'cyrillic',
      ),
    ),
    'Ultra' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Uncial Antiqua' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Underdog' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
        2 => 'cyrillic',
      ),
    ),
    'Unica One' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'UnifrakturCook' => 
    array (
      0 => 
      array (
        0 => '700',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'UnifrakturMaguntia' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Unkempt' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => '700',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Unlock' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Unna' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'VT323' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Vampiro One' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Varela' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Varela Round' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Vast Shadow' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Vibur' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Vidaloka' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Viga' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Voces' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Volkhov' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => 'italic',
        2 => '700',
        3 => '700italic',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Vollkorn' => 
    array (
      0 => 
      array (
        0 => 'regular',
        1 => 'italic',
        2 => '700',
        3 => '700italic',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Voltaire' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Waiting for the Sunrise' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Wallpoet' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Walter Turncoat' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Warnes' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Wellfleet' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Wendy One' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Wire One' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Yanone Kaffeesatz' => 
    array (
      0 => 
      array (
        0 => '200',
        1 => '300',
        2 => 'regular',
        3 => '700',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
      ),
    ),
    'Yellowtail' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Yeseva One' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
        1 => 'latin-ext',
        2 => 'cyrillic',
      ),
    ),
    'Yesteryear' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
    'Zeyada' => 
    array (
      0 => 
      array (
        0 => 'regular',
      ),
      1 => 
      array (
        0 => 'latin',
      ),
    ),
  ),
) ?>